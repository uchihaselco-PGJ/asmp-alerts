package com.asmp.dramaticalerts.command;

import com.asmp.dramaticalerts.alert.AlertData;
import com.asmp.dramaticalerts.alert.AlertManager;
import com.asmp.dramaticalerts.config.ConfigManager;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;

import java.util.List;

public final class AlertCommand {

    private AlertCommand() {}

    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(
                        ClientCommandManager.literal("asmpalert")
                                .then(ClientCommandManager.literal("reload").executes(ctx -> {
                                    ConfigManager.reload();
                                    ctx.getSource().sendFeedback(
                                            Text.literal("\u00A7a[ASMP Alerts] Ayarlar yeniden yuklendi."));
                                    return 1;
                                }))
                                .then(ClientCommandManager.argument("oyuncu", StringArgumentType.word())
                                        .then(ClientCommandManager.argument("miktar", StringArgumentType.word())
                                                .executes(ctx -> run(ctx, null))
                                                .then(ClientCommandManager.argument("seviye", StringArgumentType.word())
                                                        .suggests((c, b) -> CommandSource.suggestMatching(
                                                                List.of("EPIC", "MYTHIC", "LEGENDARY"), b))
                                                        .executes(ctx -> run(ctx,
                                                                StringArgumentType.getString(ctx, "seviye")))))))
        );
    }

    private static int run(CommandContext<FabricClientCommandSource> ctx, String levelArg) {
        String player = StringArgumentType.getString(ctx, "oyuncu");
        String amountText = StringArgumentType.getString(ctx, "miktar");

        double amount = ConfigManager.parseAmount(amountText);
        if (amount < 0) {
            ctx.getSource().sendFeedback(Text.literal(
                    "\u00A7c[ASMP Alerts] Gecersiz miktar: " + amountText + " (ornek: 60B, 1.5M, 2500K)"));
            return 0;
        }

        String level = ConfigManager.normalizeLevel(levelArg, amount);
        AlertManager.enqueue(new AlertData(player, amountText, amount, level));
        return 1;
    }
}
