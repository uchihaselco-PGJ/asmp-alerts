package com.asmp.dramaticalerts;

import com.asmp.dramaticalerts.alert.AlertManager;
import com.asmp.dramaticalerts.command.AlertCommand;
import com.asmp.dramaticalerts.config.ConfigManager;
import com.asmp.dramaticalerts.listener.ChatListener;
import com.asmp.dramaticalerts.render.AlertHudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

public final class AsmpAlertsClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ConfigManager.load();

        AlertCommand.register();
        ChatListener.register();
        AlertHudRenderer.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> AlertManager.update());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> AlertManager.clear());
    }
}
