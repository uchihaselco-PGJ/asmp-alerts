package com.asmp.dramaticalerts.listener;

import com.asmp.dramaticalerts.alert.AlertData;
import com.asmp.dramaticalerts.alert.AlertManager;
import com.asmp.dramaticalerts.config.ConfigManager;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

public final class ChatListener {

    private ChatListener() {}

    public static void register() {
        ClientReceiveMessageEvents.GAME.register((message, overlay) ->
                handle(message.getString(), overlay));
    }

    private static void handle(String text, boolean actionBar) {
        ConfigManager.ConfigData cfg = ConfigManager.get();
        if (!cfg.enabled) return;
        if (actionBar && !cfg.listenActionBar) return;
        if (!actionBar && !cfg.listenChat) return;

        ConfigManager.tryMatch(text).ifPresent(m ->
                AlertManager.enqueue(new AlertData(
                        m.playerName(),
                        m.amountText(),
                        m.amount(),
                        ConfigManager.resolveLevel(m.amount()))));
    }
}
