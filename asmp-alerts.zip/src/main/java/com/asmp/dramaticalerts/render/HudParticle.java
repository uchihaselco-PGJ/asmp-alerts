package com.asmp.dramaticalerts.render;

import com.asmp.dramaticalerts.util.EasingUtils;
import net.minecraft.client.gui.DrawContext;
import org.joml.Matrix3x2fStack;

import java.util.Random;

public final class HudParticle {

    public enum Kind { GOLD, DIAMOND, SPARK }

    private static final int[] GOLD_COLORS    = {0xFFD700, 0xFFB300, 0xFF8C00, 0xFFE866};
    private static final int[] DIAMOND_COLORS = {0x4AEDD9, 0x8DF5E8, 0xB9F2FF};
    private static final int SPARK_COLOR      = 0xFFFFFF;

    private float x, y, vx, vy;
    private float gravity, drag, size, rotation, rotSpeed;
    private float age, lifetime, delay, twinklePhase;
    private int rgb;
    private Kind kind = Kind.GOLD;
    private boolean alive;

    public boolean isAlive() {
        return alive;
    }

    public void spawn(float cx, float cy, float halfW, float halfH, float maxDelay, Random rng) {
        double angle = rng.nextDouble() * Math.PI * 2.0;
        float dirX = (float) Math.cos(angle);
        float dirY = (float) Math.sin(angle);

        this.x = cx + dirX * halfW * (0.85f + rng.nextFloat() * 0.25f);
        this.y = cy + dirY * halfH * (0.85f + rng.nextFloat() * 0.25f);

        float speed = 40f + rng.nextFloat() * 110f;
        this.vx = dirX * speed + (rng.nextFloat() - 0.5f) * 30f;
        this.vy = dirY * speed - 25f - rng.nextFloat() * 45f;

        this.gravity = 55f + rng.nextFloat() * 45f;
        this.drag = 0.9f + rng.nextFloat() * 0.8f;

        this.rotation = rng.nextFloat() * 360f;
        this.rotSpeed = (rng.nextFloat() - 0.5f) * 420f;

        this.lifetime = 2.2f + rng.nextFloat() * 2.0f;
        this.age = 0f;
        this.delay = rng.nextFloat() * Math.max(0f, maxDelay);
        this.twinklePhase = rng.nextFloat() * (float) (Math.PI * 2.0);

        float roll = rng.nextFloat();
        if (roll < 0.55f) {
            kind = Kind.GOLD;
            rgb = GOLD_COLORS[rng.nextInt(GOLD_COLORS.length)];
            size = 1.3f + rng.nextFloat() * 1.6f;
        } else if (roll < 0.85f) {
            kind = Kind.DIAMOND;
            rgb = DIAMOND_COLORS[rng.nextInt(DIAMOND_COLORS.length)];
            size = 1.4f + rng.nextFloat() * 1.8f;
        } else {
            kind = Kind.SPARK;
            rgb = SPARK_COLOR;
            size = 1.8f + rng.nextFloat() * 1.8f;
        }
        this.alive = true;
    }

    public void update(float dt) {
        if (!alive) return;
        if (delay > 0f) {
            delay -= dt;
            return;
        }
        age += dt;
        if (age >= lifetime) {
            alive = false;
            return;
        }
        vy += gravity * dt;
        vx *= Math.max(0f, 1f - drag * dt);
        if (vy > 70f) vy = 70f;
        x += vx * dt;
        y += vy * dt;
        rotation += rotSpeed * dt;
    }

    private float getAlpha() {
        if (!alive || delay > 0f) return 0f;
        float t = age / lifetime;
        float alpha = EasingUtils.envelope(t, 0.08f, 0.55f);
        float twinkle = 0.55f + 0.45f * (float) Math.sin(age * 13f + twinklePhase);
        return alpha * twinkle;
    }

    public void render(DrawContext ctx, float globalAlpha) {
        if (!alive || delay > 0f) return;
        float a = getAlpha() * globalAlpha;
        if (a <= 0.01f) return;

        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);

        switch (kind) {
            case DIAMOND -> {
                m.rotate((float) Math.toRadians(rotation + 45f));
                m.scale(size, size);
                ctx.fill(-2, -2, 2, 2, EasingUtils.setAlpha(rgb, a * 0.22f));
                ctx.fill(-1, -1, 1, 1, EasingUtils.setAlpha(rgb, a));
            }
            case SPARK -> {
                m.rotate((float) Math.toRadians(rotation));
                m.scale(size, size);
                int core = EasingUtils.setAlpha(rgb, a);
                int glow = EasingUtils.setAlpha(0xFFE680, a * 0.35f);
                ctx.fill(-3, 0, 3, 1, glow);
                ctx.fill(0, -3, 1, 3, glow);
                ctx.fill(-2, 0, 2, 1, core);
                ctx.fill(0, -2, 1, 2, core);
            }
            default -> {
                m.rotate((float) Math.toRadians(rotation));
                m.scale(size, size);
                ctx.fill(-2, -1, 2, 1, EasingUtils.setAlpha(rgb, a * 0.20f));
                ctx.fill(-1, -1, 1, 1, EasingUtils.setAlpha(rgb, a));
                ctx.fill(-1, -1, 0, 0, EasingUtils.setAlpha(0xFFFFFF, a * 0.7f));
            }
        }
        m.popMatrix();
    }
}
