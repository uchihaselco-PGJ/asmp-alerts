package com.asmp.dramaticalerts.render;

import com.asmp.dramaticalerts.alert.AlertData;
import com.asmp.dramaticalerts.alert.AlertManager;
import com.asmp.dramaticalerts.config.ConfigManager;
import com.asmp.dramaticalerts.util.EasingUtils;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;
import org.joml.Matrix3x2fStack;

import java.util.Random;

public final class AlertHudRenderer {

    private static final int CARD_W = 290;
    private static final int CARD_H = 64;
    private static final int CARD_TOP_Y = 40;
    private static final int HEAD_SIZE = 40;

    private static final int BG_COLOR = 0xCC12121A;
    private static final int GOLD = 0xFFD700;
    private static final int ORANGE = 0xFF8C00;

    private static final int RAY_COUNT = 12;
    private static final int RING_SEGMENTS = 72;

    private static final Random RNG = new Random();

    private static AlertData active;
    private static long lastFrameNanos;
    private static SkinTextures skin;
    private static String[] badgeChars = new String[0];
    private static float[] badgeOffsets = new float[0];
    private static float badgeWidth;
    private static String finalAmount = "";
    private static float finalAmountWidth;
    private static String description = "";
    private static float descWidth;
    private static float descScale = 0.85f;
    private static HudParticle[] particles = new HudParticle[0];

    private AlertHudRenderer() {}

    public static void register() {
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.SUBTITLES,
                Identifier.of("asmpalerts", "alert_overlay"),
                (ctx, tickCounter) -> {
                    if (MinecraftClient.getInstance().currentScreen == null) {
                        draw(ctx);
                    }
                });

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) ->
                ScreenEvents.afterRender(screen).register((s, ctx, mouseX, mouseY, delta) -> draw(ctx)));
    }

    private static void draw(DrawContext ctx) {
        AlertManager.update();
        AlertData alert = AlertManager.current();
        long now = System.nanoTime();

        if (alert == null) {
            active = null;
            lastFrameNanos = 0;
            return;
        }
        if (alert != active) {
            begin(ctx, alert);
        }

        float dt = lastFrameNanos == 0 ? 0f : Math.min(0.1f, (now - lastFrameNanos) / 1_000_000_000f);
        lastFrameNanos = now;

        float e = AlertManager.elapsedSeconds();
        float t = EasingUtils.clamp01(e / AlertManager.DURATION);
        float master = EasingUtils.envelope(t, 0.05f, 0.9f);
        if (master <= 0.005f) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        float cx = sw / 2f;
        float cy = CARD_TOP_Y + CARD_H / 2f;
        int accent = alert.level.accent;

        drawVignette(ctx, sw, sh, accent, master, e);
        drawRays(ctx, sw, sh, cx, cy, accent, master, e, t);
        drawFlash(ctx, sw, cx, cy, accent, e);
        drawShockwaves(ctx, cx, cy, accent, master, e);
        drawCard(ctx, tr, alert, cx, cy, accent, master, e);

        for (HudParticle p : particles) {
            p.update(dt);
            p.render(ctx, master);
        }
    }

    private static void begin(DrawContext ctx, AlertData alert) {
        active = alert;
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;

        skin = resolveSkin(mc, alert.playerName);

        String badge = alert.badgeText();
        badgeChars = new String[badge.length()];
        badgeOffsets = new float[badge.length()];
        float x = 0f;
        for (int i = 0; i < badge.length(); i++) {
            String ch = String.valueOf(badge.charAt(i));
            badgeChars[i] = ch;
            badgeOffsets[i] = x;
            x += tr.getWidth(ch) + 1.5f;
        }
        badgeWidth = Math.max(0f, x - 1.5f);

        finalAmount = "\u00A7l+$" + ConfigManager.formatAmount(alert.amount);
        finalAmountWidth = tr.getWidth(finalAmount);

        description = "\u00A7b\u00A7l" + alert.playerName + "\u00A7r\u00A7f sana \u00A76b\u00FCy\u00FCk bir \u00F6deme\u00A7f g\u00F6nderdi!";
        descWidth = tr.getWidth(description);
        float areaW = CARD_W - 12 - HEAD_SIZE - 10 - 12;
        descScale = Math.min(0.85f, areaW / Math.max(1f, descWidth));

        int count = ConfigManager.get().particleCount;
        if (particles.length != count) {
            particles = new HudParticle[count];
            for (int i = 0; i < count; i++) particles[i] = new HudParticle();
        }
        float cx = ctx.getScaledWindowWidth() / 2f;
        float cy = CARD_TOP_Y + CARD_H / 2f;
        for (HudParticle p : particles) {
            p.spawn(cx, cy, CARD_W / 2f, CARD_H / 2f, 0.6f, RNG);
        }
        lastFrameNanos = 0;
    }

    private static SkinTextures resolveSkin(MinecraftClient mc, String name) {
        try {
            ClientPlayNetworkHandler handler = mc.getNetworkHandler();
            if (handler != null) {
                PlayerListEntry entry = handler.getPlayerListEntry(name);
                if (entry != null) return entry.getSkinTextures();
            }
            return DefaultSkinHelper.getSkinTextures(Uuids.getOfflinePlayerUuid(name));
        } catch (Throwable t) {
            return null;
        }
    }

    private static void drawVignette(DrawContext ctx, int sw, int sh, int accent, float master, float e) {
        int color = EasingUtils.lerpColor(0xFF000000 | accent, 0xFF3A1060, 0.55f);
        float pulse = 0.85f + 0.15f * EasingUtils.pulse(e, 3f);
        float base = 0.34f * master * pulse;
        int steps = 14;
        int stepPx = 6;
        for (int i = 0; i < steps; i++) {
            float k = 1f - i / (float) steps;
            int c = EasingUtils.setAlpha(color, base * k * k);
            int a0 = i * stepPx;
            int a1 = a0 + stepPx;
            ctx.fill(0, a0, sw, a1, c);
            ctx.fill(0, sh - a1, sw, sh - a0, c);
            ctx.fill(a0, 0, a1, sh, c);
            ctx.fill(sw - a1, 0, sw - a0, sh, c);
        }
    }

    private static void drawRays(DrawContext ctx, int sw, int sh, float cx, float cy,
                                 int accent, float master, float e, float t) {
        float alpha = master * 0.16f * EasingUtils.easeOutCubic(EasingUtils.segment(t, 0f, 0.1f));
        if (alpha <= 0.005f) return;

        int length = (int) (Math.max(sw, sh) * 0.9f);
        int wide = EasingUtils.setAlpha(accent, alpha * 0.55f);
        int core = EasingUtils.setAlpha(0xFFFFFF, alpha);
        int none = accent & 0x00FFFFFF;

        float spin = (float) Math.toRadians(e * 8f);
        Matrix3x2fStack m = ctx.getMatrices();
        for (int i = 0; i < RAY_COUNT; i++) {
            m.pushMatrix();
            m.translate(cx, cy);
            m.rotate(spin + i * (float) (Math.PI * 2.0 / RAY_COUNT));
            ctx.fillGradient(-6, 0, 6, length, wide, none);
            ctx.fillGradient(-2, 0, 2, length, core, none);
            m.popMatrix();
        }
    }

    private static void drawFlash(DrawContext ctx, int sw, float cx, float cy, int accent, float e) {
        if (e >= 0.45f) return;
        float fade = 1f - EasingUtils.easeOutCubic(EasingUtils.segment(e, 0f, 0.45f));
        float half = sw / 2f * EasingUtils.easeOutExpo(EasingUtils.segment(e, 0f, 0.3f));
        int x1 = Math.round(cx - half);
        int x2 = Math.round(cx + half);
        int y = Math.round(cy);
        ctx.fill(x1, y - 3, x2, y + 3, EasingUtils.setAlpha(accent, fade * 0.25f));
        ctx.fill(x1, y - 1, x2, y + 1, EasingUtils.setAlpha(0xFFFFFF, fade * 0.9f));
    }

    private static void drawShockwaves(DrawContext ctx, float cx, float cy, int accent, float master, float e) {
        if (e >= 0.5f) return;

        float p1 = EasingUtils.segment(e, 0f, 0.5f);
        drawRing(ctx, cx, cy, 150f * EasingUtils.easeOutBack(p1), 3f * (1f - p1) + 1f, GOLD, (1f - p1) * master);

        float p2 = EasingUtils.segment(e, 0.06f, 0.5f);
        if (p2 > 0f) {
            drawRing(ctx, cx, cy, 230f * EasingUtils.easeOutCubic(p2), 2f * (1f - p2) + 1f, accent, (1f - p2) * master);
        }
    }

    private static void drawRing(DrawContext ctx, float cx, float cy, float radius,
                                 float thickness, int rgb, float alpha) {
        if (alpha <= 0.01f || radius < 1f) return;
        int core = EasingUtils.setAlpha(rgb, alpha);
        int glow = EasingUtils.setAlpha(rgb, alpha * 0.22f);
        int r0 = Math.round(radius);
        int r1 = r0 + Math.max(1, Math.round(thickness));
        int halfLen = (int) Math.ceil(Math.PI * radius / RING_SEGMENTS) + 1;

        Matrix3x2fStack m = ctx.getMatrices();
        for (int i = 0; i < RING_SEGMENTS; i++) {
            m.pushMatrix();
            m.translate(cx, cy);
            m.rotate(i * (float) (Math.PI * 2.0 / RING_SEGMENTS));
            ctx.fill(r0 - 3, -halfLen, r1 + 3, halfLen, glow);
            ctx.fill(r0, -halfLen, r1, halfLen, core);
            m.popMatrix();
        }
    }

    private static void drawCard(DrawContext ctx, TextRenderer tr, AlertData alert,
                                 float cx, float cy, int accent, float master, float e) {
        float enter = EasingUtils.segment(e, 0f, 0.5f);
        float scale = EasingUtils.lerp(0.6f, 1f, EasingUtils.easeOutBack(enter));
        float slide = (1f - EasingUtils.easeOutCubic(enter)) * -30f;
        float glowPulse = 0.5f + 0.5f * EasingUtils.pulse(e, 3f);

        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy + slide);
        m.scale(scale, scale);

        int x1 = -CARD_W / 2;
        int y1 = -CARD_H / 2;
        int x2 = x1 + CARD_W;
        int y2 = y1 + CARD_H;

        for (int i = 4; i >= 1; i--) {
            roundedFill(ctx, x1 - i * 2, y1 - i * 2, x2 + i * 2, y2 + i * 2,
                    EasingUtils.setAlpha(accent, master * 0.04f * glowPulse));
        }
        roundedFill(ctx, x1, y1, x2, y2, EasingUtils.withAlpha(BG_COLOR, master));

        int goldA = EasingUtils.setAlpha(GOLD, master);
        int orangeA = EasingUtils.setAlpha(ORANGE, master);
        ctx.fill(x1 + 3, y1, x2 - 3, y1 + 2, goldA);
        ctx.fill(x1 + 3, y2 - 2, x2 - 3, y2, orangeA);
        ctx.fillGradient(x1, y1 + 3, x1 + 2, y2 - 3, goldA, orangeA);
        ctx.fillGradient(x2 - 2, y1 + 3, x2, y2 - 3, goldA, orangeA);
        ctx.fill(x1 + 2, y1 + 1, x1 + 3, y1 + 2, goldA);
        ctx.fill(x1 + 1, y1 + 2, x1 + 2, y1 + 3, goldA);
        ctx.fill(x2 - 3, y1 + 1, x2 - 2, y1 + 2, goldA);
        ctx.fill(x2 - 2, y1 + 2, x2 - 1, y1 + 3, goldA);
        ctx.fill(x1 + 2, y2 - 2, x1 + 3, y2 - 1, orangeA);
        ctx.fill(x1 + 1, y2 - 3, x1 + 2, y2 - 2, orangeA);
        ctx.fill(x2 - 3, y2 - 2, x2 - 2, y2 - 1, orangeA);
        ctx.fill(x2 - 2, y2 - 3, x2 - 1, y2 - 2, orangeA);

        int hx = x1 + 12;
        int hy = -HEAD_SIZE / 2;
        ctx.fill(hx - 2, hy - 2, hx + HEAD_SIZE + 2, hy + HEAD_SIZE + 2, goldA);
        if (skin != null) {
            PlayerSkinDrawer.draw(ctx, skin, hx, hy, HEAD_SIZE);
        } else {
            ctx.fill(hx, hy, hx + HEAD_SIZE, hy + HEAD_SIZE, EasingUtils.setAlpha(0x555566, master));
            drawScaled(ctx, tr, "?", hx + HEAD_SIZE / 2f - 4f, hy + HEAD_SIZE / 2f - 8f, 2f,
                    EasingUtils.setAlpha(0xFFFFFF, master), true);
        }
        if (master < 0.98f) {
            ctx.fill(hx, hy, hx + HEAD_SIZE, hy + HEAD_SIZE, EasingUtils.setAlpha(0x12121A, (1f - master) * 0.9f));
        }

        float areaX = hx + HEAD_SIZE + 10;
        float areaW = x2 - 12 - areaX;
        float areaCx = areaX + areaW / 2f;

        float bs = 0.7f;
        float bx = areaCx - badgeWidth * bs / 2f;
        float by = -24f;
        for (int i = 0; i < badgeChars.length; i++) {
            if (badgeChars[i].equals(" ")) continue;
            float wave = Math.max(0f, (float) Math.sin(e * 6f - i * 0.5f));
            int col = EasingUtils.lerpColor(0xFF000000 | accent, 0xFFFFFFFF, wave * 0.8f);
            drawScaled(ctx, tr, badgeChars[i], bx + badgeOffsets[i] * bs, by, bs,
                    EasingUtils.setAlpha(col, master), true);
        }

        float rollP = EasingUtils.segment(e, 0f, 0.8f);
        String amountStr = rollP >= 1f
                ? finalAmount
                : "\u00A7l+$" + ConfigManager.formatAmount(alert.amount * EasingUtils.easeOutCubic(rollP));
        float pop = 0.15f * (float) Math.sin(Math.PI * EasingUtils.segment(e, 0.8f, 1.2f));
        float as = 2f * (1f + pop);
        float ax = areaCx - finalAmountWidth * as / 2f;
        float ay = -12f - pop * 9f;
        drawScaled(ctx, tr, amountStr, ax, ay, as, EasingUtils.setAlpha(GOLD, master), true);

        float dx = areaCx - descWidth * descScale / 2f;
        drawScaled(ctx, tr, description, dx, 14f, descScale, EasingUtils.setAlpha(0xFFFFFF, master), true);

        m.popMatrix();
    }

    private static void drawScaled(DrawContext ctx, TextRenderer tr, String text,
                                   float x, float y, float scale, int color, boolean shadow) {
        if ((color >>> 24) < 8) return;
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.scale(scale, scale);
        ctx.drawText(tr, text, 0, 0, color, shadow);
        m.popMatrix();
    }

    private static void roundedFill(DrawContext c, int x1, int y1, int x2, int y2, int color) {
        c.fill(x1 + 3, y1, x2 - 3, y1 + 1, color);
        c.fill(x1 + 2, y1 + 1, x2 - 2, y1 + 2, color);
        c.fill(x1 + 1, y1 + 2, x2 - 1, y1 + 3, color);
        c.fill(x1, y1 + 3, x2, y2 - 3, color);
        c.fill(x1 + 1, y2 - 3, x2 - 1, y2 - 2, color);
        c.fill(x1 + 2, y2 - 2, x2 - 2, y2 - 1, color);
        c.fill(x1 + 3, y2 - 1, x2 - 3, y2, color);
    }
}
