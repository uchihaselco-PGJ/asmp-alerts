package com.asmp.dramaticalerts.util;

public final class EasingUtils {

    private static final float C1 = 1.70158f;
    private static final float C3 = C1 + 1.0f;

    private EasingUtils() {}

    public static float clamp01(float t) {
        return t < 0f ? 0f : (t > 1f ? 1f : t);
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static float segment(float t, float start, float end) {
        if (end <= start) return t >= end ? 1f : 0f;
        return clamp01((t - start) / (end - start));
    }

    public static float easeOutCubic(float t) {
        t = clamp01(t);
        float inv = 1f - t;
        return 1f - inv * inv * inv;
    }

    public static float easeOutBack(float t) {
        t = clamp01(t);
        float p = t - 1f;
        return 1f + C3 * p * p * p + C1 * p * p;
    }

    public static float easeInOutSine(float t) {
        t = clamp01(t);
        return -(float) (Math.cos(Math.PI * t) - 1.0) / 2f;
    }

    public static float easeOutExpo(float t) {
        t = clamp01(t);
        return t >= 1f ? 1f : 1f - (float) Math.pow(2.0, -10.0 * t);
    }

    public static float envelope(float t, float fadeIn, float fadeOut) {
        t = clamp01(t);
        if (t < fadeIn) {
            return easeOutCubic(t / Math.max(fadeIn, 1e-4f));
        }
        if (t > fadeOut) {
            return 1f - easeInOutSine((t - fadeOut) / Math.max(1f - fadeOut, 1e-4f));
        }
        return 1f;
    }

    public static float pulse(float timeSeconds, float speed) {
        return 0.5f + 0.5f * (float) Math.sin(timeSeconds * speed);
    }

    public static int argb(int a, int r, int g, int b) {
        return ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }

    public static int withAlpha(int color, float alphaMul) {
        int a = (color >>> 24) & 0xFF;
        int newA = Math.round(a * clamp01(alphaMul));
        return (newA << 24) | (color & 0x00FFFFFF);
    }

    public static int setAlpha(int color, float alpha) {
        int a = Math.round(255f * clamp01(alpha));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    public static int lerpColor(int c1, int c2, float t) {
        t = clamp01(t);
        int a = (int) lerp((float) ((c1 >>> 24) & 0xFF), (float) ((c2 >>> 24) & 0xFF), t);
        int r = (int) lerp((float) ((c1 >> 16) & 0xFF), (float) ((c2 >> 16) & 0xFF), t);
        int g = (int) lerp((float) ((c1 >> 8) & 0xFF), (float) ((c2 >> 8) & 0xFF), t);
        int b = (int) lerp((float) (c1 & 0xFF), (float) (c2 & 0xFF), t);
        return argb(a, r, g, b);
    }
}
