package com.asmp.dramaticalerts.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public final class ConfigManager {

    private static final Logger LOGGER = LoggerFactory.getLogger("asmpalerts");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("asmpalerts.json");

    public record ChatMatch(String playerName, String amountText, double amount) {}

    public static final class ConfigData {
        public boolean enabled = true;
        public boolean listenChat = true;
        public boolean listenActionBar = true;
        public boolean listenTitle = true;
        public double minimumAmount = 1_000_000.0;
        public double epicThreshold = 1_000_000.0;
        public double mythicThreshold = 1_000_000_000.0;
        public double legendaryThreshold = 10_000_000_000.0;
        public List<String> patterns = new ArrayList<>(List.of(
                "(?i)(.+?) sent you \\$([0-9.,]+[KMBT]?)",
                "(?i)(.+?) paid you \\$([0-9.,]+[KMBT]?)"
        ));
        public long dedupeWindowMs = 3000L;
        public int maxQueueSize = 10;
        public float volume = 0.8f;
        public int particleCount = 36;
    }

    private static ConfigData data = new ConfigData();
    private static List<Pattern> compiledPatterns = List.of();
    private static String lastKey = "";
    private static long lastKeyTimeMs = 0L;

    private ConfigManager() {}

    public static synchronized void load() {
        ConfigData loaded = null;
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH, StandardCharsets.UTF_8)) {
                loaded = GSON.fromJson(reader, ConfigData.class);
            } catch (Exception e) {
                LOGGER.error("[ASMP Alerts] Config okunamadi, varsayilanlar kullanilacak: {}", e.toString());
            }
        }
        if (loaded == null) loaded = new ConfigData();
        sanitize(loaded);
        data = loaded;
        compilePatterns();
        save();
    }

    public static synchronized void reload() {
        load();
    }

    public static synchronized void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(data, writer);
            }
        } catch (IOException e) {
            LOGGER.error("[ASMP Alerts] Config kaydedilemedi: {}", e.toString());
        }
    }

    private static void sanitize(ConfigData c) {
        if (c.patterns == null || c.patterns.isEmpty()) c.patterns = new ConfigData().patterns;
        if (c.minimumAmount < 0) c.minimumAmount = 0;
        if (c.dedupeWindowMs < 0) c.dedupeWindowMs = 0;
        if (c.maxQueueSize < 1) c.maxQueueSize = 1;
        if (c.maxQueueSize > 100) c.maxQueueSize = 100;
        c.volume = Math.max(0f, Math.min(1f, c.volume));
        c.particleCount = Math.max(0, Math.min(80, c.particleCount));
    }

    private static void compilePatterns() {
        List<Pattern> list = new ArrayList<>();
        for (String regex : data.patterns) {
            if (regex == null || regex.isBlank()) continue;
            try {
                list.add(Pattern.compile(regex));
            } catch (PatternSyntaxException e) {
                LOGGER.error("[ASMP Alerts] Gecersiz regex atlandi: '{}' -> {}", regex, e.getDescription());
            }
        }
        compiledPatterns = List.copyOf(list);
    }

    public static ConfigData get() {
        return data;
    }

    public static Optional<ChatMatch> tryMatch(String rawMessage) {
        if (!data.enabled || rawMessage == null || rawMessage.isEmpty()) return Optional.empty();
        String message = stripFormatting(rawMessage).trim();

        for (Pattern pattern : compiledPatterns) {
            Matcher m = pattern.matcher(message);
            if (!m.find() || m.groupCount() < 2) continue;

            String player = m.group(1) == null ? "" : m.group(1).trim();
            String amountText = m.group(2) == null ? "" : m.group(2).trim();
            if (player.isEmpty() || amountText.isEmpty()) continue;

            player = extractPlayerName(player);
            double amount = parseAmount(amountText);
            if (amount < 0 || amount < data.minimumAmount) continue;
            if (isDuplicate(player, amount)) return Optional.empty();

            return Optional.of(new ChatMatch(player, amountText, amount));
        }
        return Optional.empty();
    }

    private static synchronized boolean isDuplicate(String player, double amount) {
        String key = player.toLowerCase(Locale.ROOT) + "|" + amount;
        long now = System.currentTimeMillis();
        if (key.equals(lastKey) && (now - lastKeyTimeMs) < data.dedupeWindowMs) return true;
        lastKey = key;
        lastKeyTimeMs = now;
        return false;
    }

    private static String extractPlayerName(String raw) {
        String[] parts = raw.split("\\s+");
        for (int i = parts.length - 1; i >= 0; i--) {
            String candidate = parts[i].replaceAll("[^A-Za-z0-9_]", "");
            if (candidate.length() >= 1 && candidate.length() <= 16) return candidate;
        }
        return raw;
    }

    public static String stripFormatting(String s) {
        return s.replaceAll("(?i)\u00A7[0-9A-FK-OR]", "");
    }

    public static String resolveLevel(double amount) {
        if (amount >= data.legendaryThreshold) return "LEGENDARY";
        if (amount >= data.mythicThreshold) return "MYTHIC";
        return "EPIC";
    }

    public static String normalizeLevel(String level, double amount) {
        if (level != null) {
            String up = level.toUpperCase(Locale.ROOT);
            if (up.equals("EPIC") || up.equals("MYTHIC") || up.equals("LEGENDARY")) return up;
        }
        return resolveLevel(amount);
    }

    public static double parseAmount(String raw) {
        if (raw == null) return -1;
        String s = raw.trim().replace("$", "").replace(",", "").replace("_", "").toUpperCase(Locale.ROOT);
        if (s.isEmpty()) return -1;

        double multiplier = 1.0;
        char last = s.charAt(s.length() - 1);
        switch (last) {
            case 'K' -> multiplier = 1e3;
            case 'M' -> multiplier = 1e6;
            case 'B' -> multiplier = 1e9;
            case 'T' -> multiplier = 1e12;
            default -> { }
        }
        if (multiplier != 1.0) s = s.substring(0, s.length() - 1);

        try {
            return Double.parseDouble(s) * multiplier;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    public static String formatAmount(double value) {
        String[] suffixes = {"", "K", "M", "B", "T"};
        double v = Math.abs(value);
        int idx = 0;
        while (v >= 1000.0 && idx < suffixes.length - 1) {
            v /= 1000.0;
            idx++;
        }
        String num;
        if (v >= 100.0) num = String.format(Locale.ROOT, "%.0f", v);
        else if (v >= 10.0) num = String.format(Locale.ROOT, "%.1f", v);
        else num = String.format(Locale.ROOT, "%.2f", v);
        if (num.contains(".")) num = num.replaceAll("0+$", "").replaceAll("\\.$", "");
        return num + suffixes[idx];
    }
}
