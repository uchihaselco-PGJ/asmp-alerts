package com.asmp.dramaticalerts.alert;

public final class AlertData {

    public enum Level {
        EPIC(0xB36BFF), MYTHIC(0xFF4FA3), LEGENDARY(0xFFD700);

        public final int accent;
        Level(int accent) { this.accent = accent; }
    }

    public final String playerName;
    public final String amountText;
    public final double amount;
    public final Level level;

    public AlertData(String playerName, String amountText, double amount, String levelName) {
        this.playerName = playerName;
        this.amountText = amountText;
        this.amount = amount;
        Level parsed;
        try {
            parsed = Level.valueOf(levelName);
        } catch (Exception e) {
            parsed = Level.EPIC;
        }
        this.level = parsed;
    }

    public String badgeText() {
        return "\u2605 AESIRSMP " + level.name() + " EVENT \u2605";
    }
}
