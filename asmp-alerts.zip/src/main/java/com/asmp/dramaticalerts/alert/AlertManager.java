package com.asmp.dramaticalerts.alert;

import com.asmp.dramaticalerts.config.ConfigManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

import java.util.ArrayDeque;

public final class AlertManager {

    public static final float DURATION = 5.5f;

    private static final float SPARKLE_AT = 0.3f;
    private static final float TICK_START = 0.05f;
    private static final float TICK_INTERVAL = 0.07f;
    private static final int TICK_COUNT = 11;

    private static final ArrayDeque<AlertData> QUEUE = new ArrayDeque<>();
    private static AlertData current;
    private static long startNanos;
    private static boolean sparklePlayed;
    private static int nextTick;

    private AlertManager() {}

    public static void enqueue(AlertData data) {
        if (data == null) return;
        if (current == null) {
            start(data);
        } else if (QUEUE.size() < ConfigManager.get().maxQueueSize) {
            QUEUE.addLast(data);
        }
    }

    public static AlertData current() {
        return current;
    }

    public static float elapsedSeconds() {
        return (System.nanoTime() - startNanos) / 1_000_000_000f;
    }

    public static void clear() {
        QUEUE.clear();
        current = null;
    }

    public static void update() {
        if (current == null) return;
        float e = elapsedSeconds();

        if (!sparklePlayed && e >= SPARKLE_AT) {
            sparklePlayed = true;
            play(SoundEvents.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 0.7f);
            play(SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.2f, 0.8f);
        }

        while (nextTick < TICK_COUNT && e >= TICK_START + nextTick * TICK_INTERVAL) {
            float progress = nextTick / (float) (TICK_COUNT - 1);
            play(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.9f + progress * 0.8f, 0.12f);
            nextTick++;
        }

        if (e >= DURATION) {
            AlertData next = QUEUE.pollFirst();
            if (next != null) {
                start(next);
            } else {
                current = null;
            }
        }
    }

    private static void start(AlertData data) {
        current = data;
        startNanos = System.nanoTime();
        sparklePlayed = false;
        nextTick = 0;
        play(SoundEvents.ENTITY_PLAYER_LEVELUP, 0.7f, 0.9f);
        play(SoundEvents.BLOCK_END_PORTAL_SPAWN, 1.0f, 0.2f);
    }

    private static void play(SoundEvent sound, float pitch, float volume) {
        float v = volume * ConfigManager.get().volume;
        if (v <= 0f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getSoundManager() == null) return;
        mc.getSoundManager().play(PositionedSoundInstance.master(sound, pitch, v));
    }
}
