# ASMP Dramatic Alerts

Fabric 1.21.8 client mod. /asmpalert <oyuncu> <miktar> [EPIC|MYTHIC|LEGENDARY]
